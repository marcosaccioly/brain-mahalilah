# Mind Clone: Denise Mascarenhas

> Psicóloga, escritora, fundadora do Instituto Maha Lilah. 30+ anos dedicados ao Maha Lilah como ferramenta terapêutica de autoconhecimento.

## DNA Extraído

| Arquivo | Conteúdo | Status |
|---------|----------|--------|
| `dna/voice_dna.yaml` | Como ela comunica: tom, vocabulário, frases assinatura, immune system | ✅ Completo |
| `dna/thinking_dna.yaml` | Como ela decide: frameworks, heurísticas, diagnóstico, vetos | ✅ Completo |
| `dna/mind_dna_complete.yaml` | DNA completo integrado: perfil, scope, smoke tests, output examples | ✅ Completo |

## Fidelidade

| Métrica | Valor |
|---------|-------|
| Estimativa | **92-95%** |
| Modo | PREMIUM (web + material primário completo: ebook + PPT 65 slides + caderno + receituário) |
| Fontes | 19 (7 GOLD+, 6 GOLD, 5 SILVER, 1 BRONZE) |

### Material Primário Utilizado

| Arquivo | Conteúdo Extraído |
|---------|-------------------|
| `palavras-chaves.pdf` | 72 casas completas com sânscrito e keywords |
| `caderno-de-atividades.pdf` | 8 reflexões, 5 atividades, metodologia pedagógica |
| `receituario-3.pdf` | Protocolo de sessão, 10 serpentes, 10 flechas mapeadas |
| `tabela-do-jogo.pdf` | Tabuleiro de referência |
| `tabuleiro-a3.pdf` | Tabuleiro completo com conexões visuais |

### Para aumentar fidelidade (97-99%)

1. Transcrever vídeos YouTube prioritários (6 vídeos tier 1 + 8 tier 2 = 14 essenciais)
2. Transcrever episódios do podcast Spotify (212 episódios)
3. Ler conteúdo textual completo do livro "Desvendando o Maha Lilah"
4. Sessões reais gravadas com clientes (se disponíveis)

## YouTube — Extração Completa

**Canal:** @DeniseMascarenhasMahaLilah | **Total:** 783 vídeos

| Tab | Total | Descrição |
|-----|-------|-----------|
| Videos | 435 | Mix de reflexões curtas (3-8min) e aulas (15-35min) |
| Streams | 341 | Lives "Viver Consciente" (25-60min) + Jornadas Maha Lilah |
| Shorts | 7 | Conteúdo recente sobre serpentes/flechas |

### Séries Identificadas

| Série | Qt. | Descrição |
|-------|-----|-----------|
| **Viver Consciente** | ~300+ | Lives semanais — autoconhecimento, meditação, emoções |
| **#DeniseResponde** | ~20 | FAQ sobre Maha Lilah (regras, casas, serpentes, flechas) |
| **Serpentes** | 10 | Explicação individual de cada serpente do tabuleiro |
| **Flechas** | 5 | Explicação individual de cada flecha/virtude |
| **Jornada Maha Lilah** | 19 ed. | Eventos multi-dia (3 dias + tira-dúvidas) |
| **Meditação Guiada** | ~40+ | Sessões temáticas (8-28min) |
| **Xamanismo** | ~30+ | Tambores, medicinas, rituais, aldeia nativa |
| **Contação de Histórias** | ~5+ | Narrativas arquetípicas como ferramenta terapêutica |
| **Constelação Familiar** | ~8 | Bert Hellinger, campos morfogenéticos |

### Dados Raw

| Arquivo | Conteúdo |
|---------|----------|
| `data/youtube-videos-raw.txt` | 435 vídeos (ID, título, duração, views) |
| `data/youtube-streams-raw.txt` | 341 streams (ID, título, duração, views) |
| `data/youtube-shorts-raw.txt` | 7 shorts (ID, título, views) |
| `data/youtube-extraction-catalog.yaml` | Catálogo estruturado completo |

### Transcrições (23 vídeos — 64.835 palavras)

| Tier | Vídeos | Palavras | Transcrições |
|------|--------|----------|--------------|
| **Tier 1** (Sistema ML) | 5 | 18.143 | `data/transcripts/tier1/` |
| **Tier 2** (Serpentes) | 9 | 3.465 | `data/transcripts/tier2-serpentes/` |
| **Tier 2** (Flechas) | 5 | 2.330 | `data/transcripts/tier2-flechas/` |
| **Tier 3** (Jornada 19) | 4 | 40.897 | `data/transcripts/tier3-jornada19/` |

### Frameworks Extraídos

| Arquivo | Conteúdo | Itens |
|---------|----------|-------|
| `data/mahalilah/tier1-extracted.yaml` | Frameworks, heurísticas, conceitos, protocolos, frases-assinatura | 54 itens |
| `data/mahalilah/serpentes-extracted.yaml` | 9 serpentes com padrões, indicadores terapêuticos, conexões junguianas | 9 serpentes |
| `data/mahalilah/flechas-extracted.yaml` | 5 flechas com virtudes, sombras, abordagem terapêutica | 5 flechas |
| `data/mahalilah/jornada19-extracted.yaml` | Ensino mais recente (jan/2026): frameworks, técnicas, Q&A, conteúdo novo | 67 itens |

### Conteúdo Extraído do PowerPoint (65 slides)

- 4 Modelos de Desenvolvimento da Consciência (Nativo-Americano, Junguiano, Cabalístico, Hindu)
- Descrição detalhada dos 8 Planos por chakra
- Correlação completa Eneagrama × Serpentes × Flechas (tabela 9 tipos)
- Interpretação terapêutica de cada uma das 10 serpentes (dinâmicas egóicas)
- Interpretação terapêutica de cada uma das 10 flechas (virtudes que elevam)
- Conceito de Casas Mestras / Casas de Descontinuidade
- Princípio: "Descondicionar, não adquirir" como base da evolução

## Fontes

Catálogo completo: `sources/sources-catalog.yaml`

## Uso

Este mind DNA serve como INPUT para criação de agent Maha Lilah baseado na metodologia de Denise Mascarenhas.

```
*create-agent --based-on minds/denise-mascarenhas --squad mahalila
```
